let appNome = "FreeStore"; // nome da aplicação
let WANumero = "5597981039287"; // seu número do whatsapp
let email = "admin@admin.com"; // seu email

// lista de produtos, por favor siga esse padrão
// se caso for usar imagem local, coloque o caminho absoluto inciando com ./
let produtos = [
    {
        nome: "Aplicativo Simples Delivery",
        valor: 2000.00,
        descricao: "Aplicação intuitiva, voltada para o ramo de delivery de lanches",
        imagem: "./img/Simples Delivery.png"
    },
    {
        nome: "Produto de teste",
        valor: 23.50,
        descricao: "Apenas um produto para testar",
        imagem: "./img/Simples Delivery.png"
    }
];
